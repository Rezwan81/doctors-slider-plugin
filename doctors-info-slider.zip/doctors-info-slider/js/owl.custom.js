(function($){
	'use strict';

	jQuery(document).ready(function(){
		jQuery('.sujan-doctors').owlCarousel();
	});

}(jQuery))